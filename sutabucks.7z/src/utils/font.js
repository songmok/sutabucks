export const minsize = "0.75rem"; // 12px
export const midllesize = "1.25rem"; // 20px
export const bigsize = "1.5rem"; // 24px
export const defaltsize = "1rem"; // 16px
export const headertitle = "4.06rem"; // 65px
