export const logincolor = "#880303";
export const signupcolor = "#809605";
export const themecolor = "#046241";
export const themeheadercolor = "#1b3c34";
export const ordercolor = "rgba(255, 188, 66, 0.8)";
export const footercolor = "#494848;";
