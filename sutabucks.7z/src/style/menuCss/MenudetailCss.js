import styled from "@emotion/styled";
const MenudetailCss = styled.section`
  .detail-title {
    border-top: 1px solid grey;
    border-bottom: 1px solid grey;
  }
`;

export default MenudetailCss;
