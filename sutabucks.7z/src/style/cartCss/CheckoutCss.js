import styled from "@emotion/styled";
const CheckouttCss = styled.section`
  tr {
    border-bottom: 1px solid #cccccc;
  }
`;

export default CheckouttCss;
