import React from "react";

const Loding = () => {
  return <div>Loding</div>;
};

export default Loding;
