import React from "react";

const MyStoreItem = () => {
  return <div>지점 메뉴 공사중입니다.</div>;
};

export default MyStoreItem;
{
  /* <Link to="myStoreMenu"></Link> */
}
