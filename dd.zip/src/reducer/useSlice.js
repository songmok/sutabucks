import React from "react";

const useSlice = () => {
  return <div>useSlice</div>;
};

export default useSlice;
